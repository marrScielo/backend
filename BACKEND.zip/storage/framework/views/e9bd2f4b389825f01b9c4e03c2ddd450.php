<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h2>Nuevo Pre Paciente Registrado</h2>
    <p><strong>Nombre:</strong> <?php echo e($datos['nombre']); ?></p>
    <p><strong>Celular:</strong> <?php echo e($datos['celular']); ?></p>
    <p><strong>Email:</strong> <?php echo e($datos['correo']); ?></p>
    <p><strong>Estado:</strong> <?php echo e($datos['estado']); ?></p>
</body>
</html><?php /**PATH C:\back-End-contigoVoy2\resources\views/emails/pre_paciente.blade.php ENDPATH**/ ?>